# Cars backend

To start up your server, run:

```shell
npm run start
```
