const todos = [
  { name: 'Study for exam', isDone: true, duration: 3 },
  { name: 'Finish exam', isDone: false, duration: 2 },
  { name: 'ZIP exam', isDone: false, duration: 1 },
  { name: 'Turn in exam', isDone: false, duration: 1 },
];

// Add code for question 2 and 3 here.